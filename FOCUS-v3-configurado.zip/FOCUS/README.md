# FOCUS — Organizador Acadêmico

Aplicação web responsiva para organizar matérias, atividades e anotações, com autenticação e banco de dados online usando Supabase.

## O que está incluído

- Cadastro e login por e-mail e senha.
- Painel com indicadores de matérias e atividades.
- Cadastro, listagem e exclusão de matérias.
- Cadastro, listagem, edição de status/data e exclusão de atividades.
- Cadastro, listagem e exclusão de resumos/anotações.
- Calendário de eventos acadêmicos (aulas, provas, trabalhos e compromissos).
- Cronômetro Pomodoro com ciclos de foco, pausas e histórico salvo online.
- Registro de avaliações e cinco métodos de cálculo por matéria: média ponderada, média aritmética, soma de pontos, pesos por categoria e fórmula personalizada (escala de 0 a 100).
- Relatórios de horas focadas, sessões, tarefas concluídas e resumos.
- Perfil com dados pessoais, preferências acadêmicas, tema, atualização de senha e controles de segurança.
- Filtro de atividades por status.
- Interface dark e responsiva.
- Supabase Auth, PostgreSQL e Row Level Security (RLS).

## 1. Criar o projeto Supabase

1. Acesse https://supabase.com/dashboard e crie um projeto.
2. Abra **SQL Editor**.
3. Abra o arquivo `supabase.sql` deste repositório, copie todo o conteúdo e execute. Se você já executou uma versão anterior do SQL, execute novamente o arquivo atualizado para criar as tabelas adicionais.
4. Em **Project Settings > API** (ou **API Keys**), copie:
   - Project URL
   - A chave publicável (`anon` ou `publishable`).

Nunca use a chave `service_role` no frontend.

## 2. Configurar a conexão

Abra `js/config.js` e substitua:

```js
const SUPABASE_URL = "COLE_AQUI_A_URL_DO_PROJETO";
const SUPABASE_ANON_KEY = "COLE_AQUI_A_CHAVE_PUBLICAVEL";
```

pelos dados do seu projeto Supabase.

A chave publicável pode ficar no frontend quando as tabelas estão protegidas por RLS. Não coloque senhas ou chaves secretas no Git.

## 3. Executar localmente

Não abra `index.html` diretamente com `file://`, pois o projeto usa módulos JavaScript.

No VS Code:
1. Instale a extensão **Live Server**.
2. Abra a pasta do projeto.
3. Clique com o botão direito em `index.html`.
4. Selecione **Open with Live Server**.

## 4. Publicar no GitHub

1. Crie um repositório no GitHub, por exemplo `focus-academic-organizer`.
2. Envie todos os arquivos desta pasta mantendo a estrutura.
3. Para publicar o site, habilite GitHub Pages nas configurações do repositório:
   - Settings > Pages
   - Deploy from a branch
   - Branch `main`, pasta `/ (root)`.

O GitHub Pages hospeda o frontend estático. O Supabase continua responsável pelo login e pelos dados.

## 5. Configuração de confirmação de e-mail e SMTP próprio

Por padrão, o Supabase pode exigir confirmação de e-mail no cadastro. Configure em **Authentication > URL Configuration** a URL do seu site e, durante testes, a URL local usada pelo Live Server.

Se a confirmação estiver habilitada, o usuário deverá confirmar o e-mail antes de entrar. Para evitar depender do serviço padrão de envio do Supabase, configure um SMTP dedicado. Este pacote inclui o passo a passo em [`smtp/README.md`](smtp/README.md), usando Resend como exemplo, além de modelos HTML de confirmação e recuperação em `smtp/templates/`. A senha SMTP/API Key deve ser cadastrada somente no painel seguro do Supabase, nunca no código ou GitHub.

## Observações de segurança

- RLS está habilitado nas tabelas de matérias, atividades, anotações, eventos, sessões de foco e avaliações.
- Cada registro recebe o `user_id` da conta autenticada.
- As políticas impedem que uma conta leia, altere ou exclua dados de outra.
- Não publique `service_role`, senha do banco ou tokens privados.
- Se alterar as tabelas, revise as políticas RLS antes de publicar.

## Estrutura

```text
FOCUS/
├── index.html
├── supabase.sql
├── README.md
├── css/
│   └── style.css
├── js/
│   ├── config.js
│   └── app.js
└── assets/
```

## Atualizações desta versão

- Calculadora de notas com escala de **0 a 100**.
- Cada avaliação aceita peso próprio em porcentagem. A média ponderada é calculada por `soma(nota × peso) ÷ soma dos pesos`.
- Os pesos cadastrados para uma matéria não podem ultrapassar 100%. A tela mostra o peso já preenchido.
- Perfil com nome de exibição, curso, instituição, nota mínima para aprovação, tema e pesos padrão.
- Preferência padrão de pesos: `15, 15, 70` (editável no perfil; a soma deve ser 100).
- Cinco métodos selecionáveis no Perfil: ponderada por avaliação, aritmética simples, soma de pontos, pesos por categoria e fórmula personalizada.
- Categorias editáveis em cada avaliação (ex.: Prova, Trabalho) e pesos por categoria configuráveis.
- Fórmula personalizada com variáveis `N1`, `N2`, `N3`... e operações matemáticas básicas; a expressão é interpretada por um parser restrito, sem executar JavaScript arbitrário.
- Tema claro/escuro.
- Segurança: atualização de senha e encerramento das sessões em todos os dispositivos.
- Exclusão da conta por Edge Function protegida; os registros acadêmicos vinculados são removidos pelo relacionamento `on delete cascade`.

## Atualizar o banco de dados

Abra **Supabase > SQL Editor** e execute o `supabase.sql` atualizado. Ele cria as tabelas adicionais e migra a calculadora antiga de 0–10 para 0–100 apenas quando identifica a restrição antiga. A coluna `weight` é criada com peso padrão de 15% para avaliações antigas.

> Faça uma cópia dos dados antes de executar alterações de banco em um projeto que já esteja em uso. Se você já tiver alterado manualmente a escala antiga, revise os valores antes de executar a migração automática.

## Habilitar exclusão de conta

A exclusão usa uma função de servidor para não expor a chave administrativa no navegador.

1. Instale e autentique a CLI do Supabase no computador, e vincule a pasta ao projeto (`supabase link`).
2. Configure o segredo administrativo apenas no ambiente do Supabase, nunca em `js/config.js`:

```bash
supabase secrets set SUPABASE_SERVICE_ROLE_KEY=SUA_CHAVE_SERVICE_ROLE
```

3. Publique a função:

```bash
supabase functions deploy delete-account
```

A função também usa as variáveis `SUPABASE_URL` e `SUPABASE_ANON_KEY` fornecidas pelo ambiente Supabase. O botão de exclusão só funcionará depois da implantação. Não compartilhe a chave `service_role` nem a coloque no GitHub.

## Métodos de cálculo das notas

No menu **Perfil > Método de cálculo das notas**, escolha:

1. **Média ponderada por avaliação:** cada avaliação tem seu peso; os pesos cadastrados por matéria não podem ultrapassar 100%.
2. **Média aritmética simples:** todas as avaliações têm o mesmo valor.
3. **Soma de pontos:** soma diretamente as notas cadastradas.
4. **Pesos por categoria:** informe categorias e percentuais no formato `Prova: 70, Trabalho: 30`; as médias de cada categoria são combinadas conforme esses pesos. Avaliações recebem a categoria no cadastro.
5. **Fórmula personalizada:** use `N1`, `N2`, `N3`... para referenciar avaliações na ordem de cadastro. Exemplo: `(N1 * 0.2) + (N2 * 0.3) + (N3 * 0.5)`. São aceitos números, parênteses e operações `+`, `-`, `*`, `/`.

O campo “Pesos padrão das avaliações (%)” aceita uma sequência separada por vírgulas, por exemplo `15, 15, 70`, e serve como sugestão no cadastro. Os métodos e preferências são salvos no perfil do usuário no Supabase Auth. Execute o `supabase.sql` atualizado para adicionar a coluna de categoria nas avaliações existentes.


## Versão 3

- Notas: painel "Método de cálculo da faculdade" (regra anotada por matéria + método de cálculo).
- Calendário: importação de arquivo .ics com filtro por tipo/data, tipo "Simulado" e lembretes (banner + notificação do navegador).
- Resumos: botão "Gerar mini resumo" (genérico, via Wikipédia).
- Execute o `supabase.sql` novamente (as últimas linhas são idempotentes).
